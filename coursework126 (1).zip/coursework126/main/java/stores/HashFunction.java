package stores;

public class HashFunction<T> {

}
